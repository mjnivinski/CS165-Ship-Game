var pitchRate = 75.0;
var pitchAccel = 5.0;
var rollRate = 150.0;
var rollAccel = 5.0;
var yawRate = 70.0;

//var shipSpeed = 10.0;

var shipSpeed = 120.0;

