package ris;

import ris.MyGame;
import ray.rage.Engine;
import ray.rage.scene.SceneManager;
import ray.rage.scene.SceneNode;

public class ChooseYourShip {
	public ChooseYourShip(SceneManager sm, Engine eng, MyGame g) {
		
	}
	
	private void makeScreen() {
		
	}
}
