package ris;

public interface PatrolStrategy {
	void move(float deltaTtime);
}
